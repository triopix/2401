#include <stdio.h>

int main() {
  char     a = 'P';
  char   b[] = "Jen";
  char c[50] = "";
  char    *d = "Max";

  printf("a = %c\n\n",    a);
  printf("b    = %s\n",   b);
  printf("b[0] = %c\n",   b[0]);
  printf("b[1] = %c\n",   b[1]);
  printf("b[2] = %c\n",   b[2]);
  printf("b[3] = %c\n",   b[3]);
  printf("b[4] = %c\n",   b[4]);
  printf("b[5] = %c\n\n", b[5]);
  printf("c    = %s\n\n", c);

  printf("d    = %s\n",   d);
  printf("d[0] = %c\n",   d[0]);
  printf("d[1] = %c\n",   d[1]);
  printf("d[2] = %c\n",   d[2]);
  printf("d[3] = %c\n",   d[3]);
  printf("d[4] = %c\n",   d[4]);
  printf("d[5] = %c\n\n", d[5]);

  printf("address of a    = %u\n",   (unsigned int) &a);
  printf("address of b    = %u\n",   (unsigned int) &b);
  printf("address of c    = %u\n",   (unsigned int) &c);
  printf("address of d    = %u\n",   (unsigned int) &d);
  
  return(0);
}
