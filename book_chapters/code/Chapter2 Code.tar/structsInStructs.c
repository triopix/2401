#include <stdio.h>

#define TRUE   1;
#define FALSE  0;

// Structure that represents a person's full name
typedef struct {
  char   *first;
  char   *middle;
  char   *last;
} NameType;

// Structure that represents a person's full address
typedef struct {
  char   *streetNumber;
  char   *streetName;
  char   *city;
  char   *province;
  char   *postalCode;
} AddressType;

// Structure that represents a person
typedef struct {
  NameType     name;
  AddressType  address;
  int                 age;
  char                gender;
  float               weight;
  char                retired;
} PersonType;



int main() {
  PersonType   bob;
  
  bob.name.first = "Patty";
  bob.name.middle = "O.";
  bob.name.last = "Lantern";
  bob.address.streetNumber = "187B";
  bob.address.streetName = "Oak St.";
  bob.address.city = "Ottawa";
  bob.address.province = "ON";
  bob.address.postalCode = "K6S8P2";
  bob.age = 24;
  bob.gender = 'M';
  bob.weight = 157.2;
  bob.retired = FALSE;
  
  printf("%s %s %s\n", bob.name.first, bob.name.middle, bob.name.last);
  printf("%d year old %s %s weighing %f pounds\n", bob.age, bob.retired ?  "retired": "non-retired",
	 (bob.gender == 'M') ? "male": "female", bob.weight);
  printf("Living at: %s %s, ", bob.address.streetNumber, bob.address.streetName);
  printf("%s, %s  ", bob.address.city, bob.address.province);
  printf("%s\n", bob.address.postalCode);


  return(0);
}
