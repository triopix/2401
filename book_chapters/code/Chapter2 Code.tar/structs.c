#include <stdio.h>


// Structure that represents a person's full address
struct AddressType {
  char   *name;
  char   *streetNumber;
  char   *streetName;
  char   *city;
  char   *province;
  char   *postalCode;
};



int main() {
  char *name = "Patty O. Lantern";
  char *streetNumber = "187B";
  char *streetName = "Oak St.";
  char *city = "Ottawa";
  char *province = "ON";
  char *postalCode = "K6S8P2";

  printf("%s\n", name);
  printf("%s %s\n", streetNumber, streetName);
  printf("%s, %s\n", city, province);
  printf("%s\n\n", postalCode);



  struct AddressType   addr;
  
  addr.name = "Patty O. Lantern";
  addr.streetNumber = "187B";
  addr.streetName = "Oak St.";
  addr.city = "Ottawa";
  addr.province = "ON";
  addr.postalCode = "K6S8P2";
  
  printf("%s\n", addr.name);
  printf("%s %s\n", addr.streetNumber, addr.streetName);
  printf("%s, %s\n", addr.city, addr.province);
  printf("%s\n", addr.postalCode);


  return(0);
}
