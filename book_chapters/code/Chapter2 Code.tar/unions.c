#include <stdio.h>
#include <string.h>

typedef union {
  int     i;
  float   f;
  char    c[5];
  double  d;
} Data;

typedef union {
    unsigned int  value;
    unsigned char bytes[4];
} DecomposableInteger;


typedef union {
  char whole[14];  // enough to store (613)220-2600
  struct {
    char openPar;
    char area[3];
    char closePar;
    char prefix[3];
    char dash;
    char lineNum[4];
    char null;
  } parts;
} PhoneNumber;





int main() {

  printf( "sizeof(Data): %d\n", sizeof(Data));  // returns 8

  Data   data;
  data.i = 678;
  printf( "data.i is:    %d\n", data.i)
    ;
  data.f = 3.1415;
  printf( "data.f is:    %f\n", data.f);
  
  strcpy(data.c, "Hi!");
  printf( "data.c is:    %s\n", data.c);
  
  printf( "data.i has been overwritten: %d\n", data.i);
  printf( "data.f has been overwritten: %f\n\n", data.f);

  
  DecomposableInteger   number;
  number.value = 584340;
  printf("%d, %d, %d, %d\n", number.bytes[0], number.bytes[1], number.bytes[2], number.bytes[3]);

  
  PhoneNumber myNumber;
  strcpy(myNumber.whole, "(613)520-2600");
  printf("\noriginal num: %s\n", myNumber.whole);

  strcpy(myNumber.parts.area, "416");
  strcpy(myNumber.parts.prefix, "555");
  strcpy(myNumber.parts.lineNum, "8888");
  myNumber.parts.null = 0;

  printf("whole num:    %s\n", myNumber.whole);   // corrupted now
  printf("areaCode:     %s\n", myNumber.parts.area);
  printf("prefix:       %s\n", myNumber.parts.prefix);
  printf("lineNumber:   %s\n", myNumber.parts.lineNum);

  return 0;
}

