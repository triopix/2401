#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUMBER_OF_SCORES         8
#define NUMBER_OF_PERFORMANCES   3



typedef struct {      // Structure that represents Dive data
  char  *name;
  int    difficulty;
} DiveType;

typedef struct {      // Structure that represents Performance data
  DiveType   dive;
  float      scores[NUMBER_OF_SCORES];
} PerformanceType;

typedef struct {      // Structure that represents Athlete data
  char            *name;
  char            *country;
  PerformanceType  performances[NUMBER_OF_PERFORMANCES];
} AthleteType;

DiveType     dives[5];     // An array to hold the 5 types of dives
AthleteType  athletes[3];  // An array to hold the 3 athletes


// Procedure that displays an athlete, his/her performances as well as 
// the 8 individual scores for each performance.
void displayAthlete(AthleteType  athlete) {
  printf("Athlete: %s from %s:\n", athlete.name, athlete.country);
  for (int p=0; p<NUMBER_OF_PERFORMANCES; p++) {
      printf("  Performed %s (diff: %d): [",
	     athlete.performances[p].dive.name,
	     athlete.performances[p].dive.difficulty);
    
      for (int s=0; s<NUMBER_OF_SCORES; s++) {
	     printf("%0.2f",athlete.performances[p].scores[s]);
          if (s != NUMBER_OF_SCORES-1)
	       printf(", ");
      }
      printf("]\n");
    }
  printf("\n");
}


int main() {
  // Fill in the athletes array with 3 athletes
  athletes[0].name = "Art Class";
  athletes[0].country = "Canada";
  athletes[1].name = "Dan Druff";
  athletes[1].country = "Germany";
  athletes[2].name = "Jen Tull";
  athletes[2].country = "U.S.A.";

  // Fill in the dives array with 5 dives
  dives[0].name = "reverse pike";
  dives[0].difficulty = 3;
  dives[1].name = "cannon ball";
  dives[1].difficulty = 1;
  dives[2].name = "reverse triple twist";
  dives[2].difficulty = 4;
  dives[3].name = "forward pike";
  dives[3].difficulty = 2;
  dives[4].name = "inward straight twist";
  dives[4].difficulty = 5;

  // Assign random performances to athletes and generate random scores
  srand(time(NULL));
  for (int a=0; a<3; a++) {
    for (int p=0; p<NUMBER_OF_PERFORMANCES; p++) {
      // choose a random dive for this performance
      athletes[a].performances[p].dive = 
                                dives[(int)(rand()/(double)RAND_MAX*5)];
      for (int s=0; s<NUMBER_OF_SCORES; s++) {
	   // choose a random judge's score
	   athletes[a].performances[p].scores[s] = 
                                             rand()/(double)RAND_MAX*10;
      }
    }
  }

  // Display the results
  for (int a=0; a<3; a++)
    displayAthlete(athletes[a]);

  return(0);
}