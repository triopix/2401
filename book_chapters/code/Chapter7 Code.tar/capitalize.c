#include <stdio.h>
#include <string.h>

#include "names.h"  // This is our own header, hence double quotes

int main() {
  NameType    newName;

  while (1) {
    enterName(&newName);

    if (strcmp(newName.first,"-1") == 0 && strcmp(newName.last,"-1") == 0)
      break;

    capFix(newName.first);
    capFix(newName.last);

    printf("My name is %s %s\n", newName.first, newName.last);
  }
}

