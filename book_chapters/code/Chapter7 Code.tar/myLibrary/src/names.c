#include <stdio.h>
#include <string.h>
#include "names.h"  // this is our own header, hence double quotes

// Get a first and last name from stdin
void enterName(NameType *name) {
  printf("\n");
  printf("Enter a name: ");
  scanf("%s %s", name->first, name->last);
}

// Fix name by capitalizing it properly
void capFix(char *str) {
  // Check the first letter and capitalize it
  if (str[0] >= 'a' && str[0] <= 'z')
    str[0] = str[0] - 32; // 32 is ASCII diff between 'A' and 'a'

  // Uncapitalize the remaining letters
  for (int i=1; i<strlen(str); i++)
    if (str[i] >= 'A' && str[i] <= 'Z')
      str[i] = str[i] + 32; // 32 is ASCII diff between 'A' and 'a'
}

