#define MAX_STR 32

typedef struct {
  char first[MAX_STR];
  char last[MAX_STR];
} NameType;


extern void enterName(NameType *name);
extern void capFix(char *str);

