#include <stdio.h>

void function1() {
  static int i = 0;

  i = i + 2;  
  printf("%d ", i);
}

void function2() {
  int i = 0;

  i = i + 2;  
  printf("%d ", i);
}

int main() {
  function1();
  function1();
  function1();
  printf("\n");
  function2();
  function2();
  function2();
  printf("\n");
}




