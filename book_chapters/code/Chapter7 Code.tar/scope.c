#include <stdio.h>

extern void simpleFunc(int x);  // This is defined in "util.c"

int x = 10;                     // This will be accessed from "util.c"

int main() {
  x = x + 10;
  printf("main:   x = %d\n", x);

  int x = 5;
  x = x + 10;
  printf("main:   x = %d\n", x);

  {
    int x = 8;
    x = x + 10;
    printf("inner:  x = %d\n", x);
  }

  printf("main:   x = %d\n", x);
  simpleFunc(x);
  printf("main:   x = %d\n", x);
} 



