#include <stdio.h>

extern int x;   // This is defined in "scope.c"

void simpleFunc(int z) {
  x = x + 10;
  printf("func:   x = %d\n", x);
} 
