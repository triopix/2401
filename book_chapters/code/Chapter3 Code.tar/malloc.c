#include <stdio.h>
#include <stdlib.h>

int main() {
  int   nums = 5;
  int  *grades, *gradesStart;

  grades = (int *) gradesStart = malloc(nums * sizeof(int));
  if (grades == NULL) { 
    printf("Memory allocation error\n"); 
    exit(0); 
  }
  grades[0]   = 10;
  grades[1]   = 20;
  grades[2]   = 30;
  *(grades+3) = 40;
  *(grades+4) = 50;

  for (int i=0; i<nums; i++)
    printf("%d ", grades[i]);  // use it like an array
  printf("\n");

  for (int i=0; i<nums; i++) 
    printf("%d ", *grades++);  // use it via pointers
  printf("\n");

  free(gradesStart);
}
