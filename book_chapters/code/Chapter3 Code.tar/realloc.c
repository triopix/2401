#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
  char  *string;

  string = (char *)malloc(10);
  strcpy(string, "Small");
  printf("Initial String = \"%s\" stored at address = %p\n", 
         string, (void *) string);

  string = (char *)realloc(string, 40);
  strcat(string, ", but now the string is bigger.");
  printf("Bigger String = \"%s\" stored at address = %p\n", 
         string, (void *) string);

  free(string); 
}