#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define ARRAY_SIZE 10


int compareIncreasing(const void *p1, const void *p2) {
  int n1 = *(int *)p1;
  int n2 = *(int *)p2;
  
  if (n1 < n2) return -1;
  if (n1 > n2) return 1;
  return 0;
}



int compareDecreasing(const void *p1, const void *p2) {
  int n1 = *(int *)p1;
  int n2 = *(int *)p2;
  
  if (n1 < n2) return 1;
  if (n1 > n2) return -1;
  return 0;
}


int compareDigits(const void *p1, const void *p2) {
  int n1 = *(int *)p1;
  int n2 = *(int *)p2;
  char s1[10], s2[10];

  sprintf(s1, "%d", n1);
  sprintf(s2, "%d", n2);
  
  if (strlen(s1) < strlen(s2)) return -1;
  if (strlen(s1) > strlen(s2)) return 1;
  return 0;
}


int main() {
  int arr[ARRAY_SIZE];
 
  for(int i=0; i<ARRAY_SIZE; i++)
    arr[i] = rand()%20 * (rand()%20);

  printf("Before qsort() \n");
  for(int i=0; i<ARRAY_SIZE; i++)
    printf("%d\n", arr[i]);

  qsort(arr, ARRAY_SIZE, sizeof(int), compareIncreasing);

  printf("\nAfter qsort() in Increasing Order\n");
  for(int i=0; i<ARRAY_SIZE; i++)
    printf("%d\n", arr[i]);


  qsort(arr, ARRAY_SIZE, sizeof(int), compareDecreasing);

  printf("\nAfter qsort() in Decreasing Order\n");
  for(int i=0; i<ARRAY_SIZE; i++)
    printf("%d\n", arr[i]);

  qsort(arr, ARRAY_SIZE, sizeof(int), compareDigits);

  printf("\nAfter qsort() in Digit Count Order\n");
  for(int i=0; i<ARRAY_SIZE; i++)
    printf("%d\n", arr[i]);
}
