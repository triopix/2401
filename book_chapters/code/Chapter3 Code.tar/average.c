#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  double total = 0;
  
  for (int i=1; i<argc; ++i)
    total += atoi(argv[i]);
    
  printf("The average of those %d numbers is %0.1f\n", argc-1, total/(argc-1));
}
