#include <stdio.h>
#include <stdlib.h>

int add(int x, int y) { return (x + y); }
int subtract(int x, int y) { return (x - y); }
int multiply(int x, int y) { return (x * y); }
int divide(int x, int y) { return (x / y); }

int main() {
  int (*fPtr[4])(int, int) = {add, subtract, multiply, divide};

  for (int i=0; i<4; i++) 
    printf("%d\n", fPtr[i](2,5));
}