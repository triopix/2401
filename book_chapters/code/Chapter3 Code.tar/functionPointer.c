#include <stdio.h>
#include <stdlib.h>

int add(int x, int y) {
  return (x + y);
}
int subtract(int x, int y) {
  return (x - y);
}
int multiply(int x, int y) {
  return (x * y);
}

int main() {
  int (*fPtr)(int, int);
    
  fPtr = add;
  printf("%d\n", fPtr(2, 5));	 // call the add function 
  
  fPtr = subtract;    
  printf("%d\n", fPtr(2, 5));  // Call the subtract function

  fPtr = multiply;    
  printf("%d\n", fPtr(2, 5));  // Call the multiply function
}