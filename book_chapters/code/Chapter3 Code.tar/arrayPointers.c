#include <stdio.h>

int main() {
  int  intArr[8] = {23, 54, 67, 88, 43, 12, 83, 46};

  printf("int array addr: %p \n", (void *)intArr);
  printf("First item addr:%p \n", (void *)&intArr[0]);
  printf("Last item addr: %p \n\n", (void *)&intArr[7]);
  
  printf("First int:        %d \n", intArr[0]);
  printf("First int again:  %d \n", *intArr);
  printf("First int plus 3: %d \n", *intArr + 3);
  printf("Fourth int:       %d \n", *(intArr + 3));
  printf("\n");

  int  *ptr;
  
  ptr = &(intArr[6]);
  ptr = intArr + 6;  // does same as above

  printf("Seventh int: %d \n", *ptr);
  printf("Eighth int:   %d \n", ptr[1]);
  printf("Fifth int:   %d \n", *(ptr - 2));

  char charArr[32] = "SAM PULL";

  printf("\n");
  printf("char array addr:%p \n", (void *)charArr);
  printf("First item addr:%p \n", (void *)&charArr[0]);
  printf("Last item addr: %p \n\n", (void *)&charArr[7]);
  
  printf("First char:        %c \n", charArr[0]);
  printf("First char again:  %c \n", *charArr);
  printf("First char plus 4: %c \n", *charArr + 4);
  printf("Fifth char:        %c \n", *(charArr + 4));
  printf("\n");

  char  *cptr;

  cptr = &(charArr[4]);
  cptr = charArr + 4;  // does same as above

  printf("Fifth char: %c \n", *cptr);
  printf("Sixth char: %c \n", cptr[1]);
  printf("Third char: %c \n", *(cptr - 2));
  printf("\n");

  return 0;
}