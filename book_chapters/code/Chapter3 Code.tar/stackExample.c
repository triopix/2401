#include <stdio.h>

int add(int n1, int n2) {
  int sum = n1 + n2;
  return sum;
}

float avg(int m1, int m2, int m3) {
  int ttl = add(m1, m2) + m3;
  return ttl/3.0;
}

void stat(int i1, int i2, int i3) {
  float r = avg(i1, i2, i3);
  //printf("%0.2f\n", r);
}

int main() {
  int  t = 30;

  stat(t, 25, 55);

  return -1;
}
