#include <stdlib.h>

int main() {
  int   nums = 5;
  int  *grades;

  grades = (int *) malloc(nums * sizeof(int));
  free(grades);
}
