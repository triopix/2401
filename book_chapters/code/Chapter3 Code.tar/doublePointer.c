#include <stdio.h>
#include <stdlib.h>

void getRandomArrays(int **a1, int **a2, int amount) {
  *a1 = (int *) malloc(amount * sizeof(int));
  *a2 = (int *) malloc(amount * sizeof(int));
  if ((a1 == NULL) || (a2 == NULL)) { 
    printf("Memory allocation error\n"); 
    exit(0); 
  }
  for (int i=0; i<amount; i++) {
    (*a1)[i] = rand();
    (*a2)[i] = rand();
  }
}

int main() {
  int  *array1 = NULL, *array2 = NULL;

  getRandomArrays(&array1, &array2, 5);

  for (int i=0; i<5; i++) 
    printf("%d ", array1[i]); 
  printf("\n");
  
  for (int i=0; i<5; i++) 
    printf("%d ", array2[i]); 
  printf("\n");
  
  free(array1);
  free(array2);
}




