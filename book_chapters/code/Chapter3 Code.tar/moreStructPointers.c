#include <stdio.h>
#include <string.h>

#define MAX_STUDENTS   250
#define MAX_STR         64


typedef struct {
  char first[MAX_STR];
  char last[MAX_STR];
  int   age;
} PersonType;

typedef struct {
  PersonType   personalInfo;
  char        stuNumber[MAX_STR];
  float        gpa;
} StudentType;

// Functions/Procedures used in this program
void increaseAge(StudentType *);
void printStudent(StudentType *);

int main() {
  StudentType students[MAX_STUDENTS];
  int         numStudents = 3;

  printf("StudentType requires %lu bytes\n", sizeof(StudentType));

  strcpy(students[0].personalInfo.first, "April");
  strcpy(students[0].personalInfo.last, "Rain");
  students[0].personalInfo.age = 22;
  strcpy(students[0].stuNumber, "100444555");
  students[0].gpa = 9.0;
  strcpy(students[1].personalInfo.first, "May");
  strcpy(students[1].personalInfo.last, "Flowers");
  students[1].personalInfo.age = 24;
  strcpy(students[1].stuNumber, "100222333");
  students[1].gpa = 8.7;
  strcpy(students[2].personalInfo.first, "June");
  strcpy(students[2].personalInfo.last, "Bugs");
  students[2].personalInfo.age = 99;
  strcpy(students[2].stuNumber, "100777888");
  students[2].gpa = 11.5;

  printf("Age before increasing: %d\n", students[0].personalInfo.age);
  increaseAge(&students[0]); 
  printf("Age after increasing: %d\n\n", students[0].personalInfo.age);

  StudentType *studentPtr = students;
  for (int i=0; i<numStudents; i++) {
    printf("studentPtr = %p\n", (void *)studentPtr);
    increaseAge(studentPtr);
    printStudent(studentPtr);
    ++studentPtr;  // Go to the next student
  }
  printf("\n");
  return 0;
}

// Increases the student's age
void increaseAge (StudentType *s) {
  s->personalInfo.age++;
}

// Displays student to the console showing name, age and GPA.
void printStudent (StudentType *s) {
  printf("%d year old %s %s has a GPA of %.1f \n", 
         s->personalInfo.age,
	   s->personalInfo.first,
	   s->personalInfo.last,
	   s->gpa);
}
