#include <stdio.h>
#include <stdlib.h>

int processArray(int *arr, char (*shouldPrint)(int *)) {
  for (int i=0; i<10; i++, arr++)
    if (shouldPrint(arr))
       printf("%d\n", *arr);
}

char odd(int *num) {
  return (*num%2 == 1); 
}
char even(int *num) { 
  return (*num%2 == 0); 
}
char all(int *num) { 
  return 1; 
}
int main() {
  int arr[10] = {11, 14, 22, 34, 41, 53, 61, 76, 87, 98};

  printf("Odd:\n");
  processArray(arr, odd);
  printf("\nEven:\n");
  processArray(arr, even);
  printf("\nAll:\n");
  processArray(arr, all);
}