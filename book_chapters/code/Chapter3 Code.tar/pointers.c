#include <stdio.h>

int main() {
  int     income;
  int    *salary;

  income = 45700;
  salary = &income; // make it a pointer to the income variable
  
  printf("income = %u\n", income);
  printf("salary = %u\n\n", (unsigned int)salary);
  printf("address of income = %u\n", (unsigned int)&income);
  printf("address of salary = %u\n", (unsigned int)&salary);

  
  income = 52300;
  printf(" salary = %u\n", (unsigned int)salary);     // prints same address
  printf("*salary = %u\n\n", (unsigned int)*salary);  // prints 52300

  
  *salary = 36340;
  printf("income = %u\n", income);                    // prints 36340
  printf(" salary = %u\n", (unsigned int)salary);     // prints same address
  printf("*salary = %u\n\n", *salary);  // prints 36340



  salary = NULL;
  printf(" salary = %u\n", (unsigned int)salary); 
  //printf("*salary = %u\n", *salary);  // BAD IDEA! ... Segmentation Fault
  //*salary = 200;                      // BAD IDEA! ... Segmentation Fault
 
  if (salary != NULL)
    printf("*salary = %u\n", *salary);
  if (salary != NULL)
    *salary = 200;           
  
  return(0);
}
