int   x = 890;
const char  *c = "HELLO";

int main() {
  static float y = 200.67;
}
