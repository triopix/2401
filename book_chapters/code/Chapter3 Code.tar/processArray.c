#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 10

int processArray(int *arr, void (*printFunction)(int *)) {
  for (int i=0; i<ARRAY_SIZE; i++, arr++)
    printFunction(arr);
}

void printOdd(int *num) {
  if (*num %2 == 1) printf("%d\n",*num);
}

void printEven(int *num) {
  if (*num %2 == 0) printf("%d\n",*num);
}

int main() {
  int arr[10] = {11, 14, 22, 34, 41, 53, 61, 76, 87, 98};

  printf("Odd:\n");
  processArray(arr, printOdd);
  printf("\nEven:\n");
  processArray(arr, printEven);
}