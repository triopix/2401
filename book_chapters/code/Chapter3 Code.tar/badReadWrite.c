#include <stdio.h>
#include <stdlib.h>

int main() {
  int   nums = 5;
  int  *grades;

  grades = (int *) malloc(nums * sizeof(int));

  grades[0]  = 10;
  grades[1]  = 20;
  grades[2]  = 30;
  grades[67] = 4544;          // this is an invalid write

  printf("%d\n", grades[99]); // this is an invalid read

  free(grades);
}
