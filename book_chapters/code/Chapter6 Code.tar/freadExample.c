#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct person {
  char  name[10];
  int   age;
  float weight;
};

  
int main() {
  FILE  *fd;  

  // Open the file for reading only
  fd = fopen("sampleFile.dat", "r");
  if (!fd) {
     printf("ERROR: Could not open file\n");
     exit(1);
  }

  // Read in a float
  float  data;
  fread(&data, sizeof(float), 1, fd);
  printf("Here is the float: %f\n", data);
  
  // Read in a string of 30 chars
  char  sentence[30];
  fread(sentence, sizeof(char), 30, fd);
  printf("Here is the sentence: \"%s\"\n", sentence);

  // Read in a whole array of ints
  int intArray[5];
  fread(intArray, sizeof(intArray), 1, fd);
  printf("\nHere is the array: {");
  for (int i=0; i<5; i++)
    printf("%d,", intArray[i]);
  printf("}\n");

  // Read in first three elements of the array
  fread(intArray, sizeof(int), 3, fd);
  printf("\nHere are the first three elements of the array: {");
  for (int i=0; i<3; i++)
    printf("%d,", intArray[i]);
  printf("}\n");

  // Read in an array of structs
  struct person friends[4];
  fread(friends, sizeof(friends), 1, fd);
  printf("\nHere are the friends:\n");
  for (int i=0; i<4; i++)
    printf("  Name: %s,  Age: %d,  Weight: %f\n", friends[i].name,
	   friends[i].age, friends[i].weight);


  // Read in a single friend
  struct person friend;
  fread(&friend, sizeof(struct person), 1, fd);
  printf("\nHere is the first friend:\n");
  printf("  Name: %s,  Age: %d,  Weight: %f\n", friend.name,
	   friend.age, friend.weight);
  printf("\n");

  // All done ... close the file
  fclose(fd);
}
