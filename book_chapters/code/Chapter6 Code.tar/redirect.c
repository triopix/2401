#include <stdio.h>

#define MAX_NUMS 100

int main() {
  int arr[MAX_NUMS];
  int num, currMax; 
  int count = 0;

  while (1) {
    scanf("%d", &num);
    if (num < 0)
      break;
    arr[count++] = num;
    if (count == MAX_NUMS)
      break;
  }

  currMax = 0;
  for (int i=0; i<count; i++) {
    if (arr[i] > currMax)
      currMax = arr[i];
  }
  printf("Max=%d\n", currMax);
}
