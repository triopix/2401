#include <stdio.h>
#include <stdlib.h>
  
int main() {
  FILE  *fd;
  int    data;
    
  // Read in the file with the 10 integers
  fd = fopen("integers.dat", "r+");
  printf("Original file values:\n");
  while ((fread(&data, sizeof(int), 1, fd)) > 0) {
    printf("%d, ", data);
  }

  // Position the file marker and read in the 8th integer
  fseek(fd, sizeof(int)*7, SEEK_SET); // 7 since first integer starts at 0
  fread(&data, sizeof(int), 1, fd);

  // Increase the value and re-write
  data = data + 10;
  fseek(fd, sizeof(int)*7, SEEK_SET);
  fwrite(&data, sizeof(int), 1, fd);

  // Position back to  the start
  fseek(fd, 0, SEEK_SET);

  // Display the values of the file again
  printf("\nModified file values:\n");
  while ((fread(&data, sizeof(int), 1, fd)) > 0) {
    printf("%d, ", data);
  }
  printf("\n");
  fclose(fd);
}
