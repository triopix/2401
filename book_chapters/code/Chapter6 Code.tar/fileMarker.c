
#include <stdio.h>
#include <stdlib.h>

int main() {
  FILE  *fd;  

  // Write out 10 random integers
  fd = fopen("integers.dat", "w+"); // read & write

  for (int i = 0; i<10; i++) {
    int data = (int)(rand()/(double)RAND_MAX*100);
    fwrite(&data, sizeof(int), 1, fd);
  }
  rewind(fd);  // Reset to the beginning so we can read it in
  
  // Read in the 10 integers and show the file marker moving
  int    data;  
  printf("File Marker starts at: %lu\n", ftell(fd));

  while ((fread(&data, sizeof(int), 1, fd)) > 0) {
    printf("Read in value: %d, File Marker moved to: %lu\n", data, ftell(fd));
  }

  printf("fread() returned -1, EOF reached\n");
  fclose(fd);
}
