#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct person {
  char  name[10];
  int   age;
  float weight;
};

int main() {
  FILE  *fd;  

  // Open the file for reading only
  fd = fopen("sampleFile.txt", "r");
  if (!fd) {
     printf("ERROR: Could not open file\n");
     exit(1);
  }

  // Read in a float
  float  data;
  fscanf(fd, "%f\n", &data);
  printf("Here is the float: %f\n", data);
  
  // Read in a string of 30 chars
  char  sentence[30];
  fscanf(fd, "%30c\n", sentence);
  printf("Here is the sentence: \"%s\"\n", sentence);

  // Read in a whole array of ints
  int intArray[5];
  printf("\nHere is the array: {");
  for (int i=0; i<5; i++) {
    fscanf(fd, "%d", &intArray[i]);
    printf("%d,", intArray[i]);
  }
  printf("}\n");
  fscanf(fd, "\n");

  // Read in first three elements of the array
  printf("\nHere are the first three elements of the array: {");
  for (int i=0; i<3; i++) {
    fscanf(fd, "%d", &intArray[i]);
    printf("%d,", intArray[i]);
  }
  printf("}\n");
  fscanf(fd, "\n");

  // Read in an array of structs
  struct person friends[4];
  printf("\nHere are the friends:\n");
  for (int i=0; i<4; i++) {
    fscanf(fd, "%s %d %f\n", friends[i].name,&friends[i].age,&friends[i].weight);
    printf("  Name: %s,  Age: %d,  Weight: %f\n", friends[i].name,
	     friends[i].age, friends[i].weight);
  }

  // Read in a single friend
  struct person friend;
  fscanf(fd, "%s %d %f\n", friend.name, &friend.age, &friend.weight);
  printf("\nHere is the first friend:\n");
  printf("  Name: %s,  Age: %d,  Weight: %f\n", friend.name,
	   friend.age, friend.weight);
  printf("\n");

  // All done ... close the file
  fclose(fd);
}