#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct person {
  char  name[10];
  int   age;
  float weight;
};

  
int main() {
  FILE  *fd;  

  // Open a new file for writing only
  fd = fopen("sampleFile.dat", "w");
  if (!fd) {
     printf("ERROR: Could not open file\n");
     exit(1);
  }

  // Write out a float
  float  data = 1078.24;
  fwrite(&data, sizeof(float), 1, fd);
  
  // Write out a string of 30 chars
  char  sentence[30] = "This is a sentence.";
  fwrite(sentence, sizeof(char), 30, fd);

  // Write out a whole array of ints
  int intArray[5] = {12, 34, 56, 78, 90};
  fwrite(intArray, sizeof(intArray), 1, fd);

  // Write out first three elements of the array
  fwrite(intArray, sizeof(int), 3, fd);

  // Write out an array of structs
  struct person friends[4] = {{"Bobby", 19, 143.57},
			      {"Jenny", 20, 110.32},
			      {"Fredy", 82, 178.29},
			      {"Marie", 67, 121.32}};
  fwrite(friends, sizeof(friends), 1, fd);

  // Write out a single friend, Bob
  fwrite(friends, sizeof(struct person), 1, fd);

  // All done ... close the file
  fclose(fd);
}
