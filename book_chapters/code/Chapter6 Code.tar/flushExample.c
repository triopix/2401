#include <stdio.h>
#include <unistd.h>

int main() {
  // "Block" buffering
  printf("Here is an example of block buffering:\n");
  for (int i=1; i<=5; i++) {
    printf("%d ", i);
    sleep(1);
  }
  printf("\n");

  // Line buffering
  printf("Here is an example of line buffering:\n");
  for (int i=1; i<=5; i++) {
    printf("%d\n", i);
    sleep(1);
  }

  // No/unblocked buffering
  printf("Here is an example of no/unblocked buffering:\n");
  for (int i=1; i<=5; i++) {
    printf("%d ", i);
    fflush(stdout);
    sleep(1);
  }
  printf("\n");
}
