/***********************************************************/
/* This program prompts the user for an array of integers  */
/* and then finds the maximum and prints it to the screen. */
/* It does t his by creating three functions.  One to get  */
/* the data from the user, one to display the array and    */
/* the last one to compute and return the maximum.         */
/***********************************************************/

#include <stdio.h>

#define MAX_SIZE  10  // maximum numbers allowed to be entered by the user


// Function definitions
//void displayArray(int *, int);
//int findMaximum(int *, int);
//int getArrayData(int *);


int main() {
  int array[MAX_SIZE];
  
  int totalNums = getArrayData(array);      // Get the numbers from the user
  displayArray(array, totalNums);           // Print the array

  int max = findMaximum(array, totalNums);  // Compute the maximum of the array
  printf("\nMax is %d\n", max);             // Print the maximum

  return(0);
}


/*****************************************/
/* Display the values of the given array */
/*****************************************/
void displayArray(int *theArray, int theArraySize) {
  printf("\nHere is the array:\n");
  for (int i=0; i<theArraySize; i++)
    printf("%2d: %d\n",i, theArray[i]);
}

/********************************************************/
/* Find and return the maximum value of the given array */
/********************************************************/
int findMaximum(int *theArray, int theArraySize) {
  int m = 0;
  for (int i=0; i<theArraySize; i++) {
    if (theArray[i] > m)
      m = theArray[i];
  }
  return m;
}

/************************************************************/
/* Prompt the user for values and place them into the given */
/* array until the array is full or -1 is entered           */
/************************************************************/
int getArrayData(int *theArray) {
  int  count = 0;
  int  num;
  do {
    printf("Enter a number:  ");
    scanf("%d", &num);

    if (num != -1)
      theArray[count++] = num;
      
  } while ((count < MAX_SIZE) && (num != -1));
  return count;
}
