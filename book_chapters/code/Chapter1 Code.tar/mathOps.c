#include <stdio.h>

int main() {
  int x, y, z;

  x = 4;
  y = x;

  z = y + 2 * x - 3;

  printf("%d %d %d\n", x, y, z);

  if (x == y)
    printf("x equal to y\n");
  else
    printf("x not equal to y\n");

  printf("%s\n", ( (y == z) ? "y equal to z" : "y not equal to z" ));

  x = y = 7;
  z -= x;
  y *= z;
  printf("%d %d %d\n", x, y, z);

  printf("prefix:   %d\n", ++x);
  printf("postfix:  %d\n", x++);
  printf("next:     %d\n\n", x);

  printf("y:      %d\n", y);
  printf("y + 1:  %d\n", y + 1);
  printf("y:      %d\n", y);
  printf("++y:    %d\n", ++y);
  printf("y:      %d\n\n", y);

  y += 1;
  printf("after y += 1:  %d\n\n", y);

  y + 1;
  printf("after y + 1:   %d\n\n", y);

  return(0);
}
