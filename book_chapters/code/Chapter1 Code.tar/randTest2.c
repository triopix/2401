#include <stdio.h>
#include <stdlib.h>

int main() {
  srand(1);
  for (int i = 0; i<5; i++)
    printf("%d\n", (int)(rand()/(double)RAND_MAX*100)); // 84, 39, 78, 79, 91

  srand(2);
  for (int i = 0; i<5; i++)
    printf("%d\n", (int)(rand()/(double)RAND_MAX*100));  // 70, 80, 8, 12, 34

  srand(683);
  for (int i = 0; i<5; i++)
    printf("%d\n", (int)(rand()/(double)RAND_MAX*100)); // 75, 10, 18, 10, 91

}
