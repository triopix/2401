#include <stdio.h>

int main() {
  int       ages[]    = {34, 12, 45}; 
  double    weights[] = {4.5, 23.6, 84.1, 78.2, 61.5};
  char      vowels[]  = {'a', 'e', 'i', 'o', 'u'};

  printf("\nHere is the ages array:\n");
  for (int i=0; i<3; i++)
    printf("%2d: %d\n",i, ages[i]);
  
  printf("\nHere is the weights array:\n");
  for (int i=0; i<5; i++)
    printf("%2d: %g\n",i, weights[i]);
  
  printf("\nHere is the vowels array:\n");
  for (int i=0; i<5; i++)
    printf("%2d: %c\n",i, vowels[i]);

  return(0);
}
