#include <stdio.h>

int main() {
  int    kind;
  float  cost;
  char   size;

  printf("Luigi's Pizza                              \n");
  printf("-------------------------------------------\n");
  printf("                     S(SML)  M(MED)  L(LRG)\n");
  printf("1. Cheese             5.00    7.50   10.00 \n");
  printf("2. Pepperoni          5.75    8.63   11.50 \n");
  printf("3. Combination        6.50    9.75   13.00 \n");
  printf("4. Vegetarian         7.25   10.88   14.50 \n"); 
  printf("5. Meat Lovers        8.00   12.00   16.00 \n\n");

  printf("What kind of pizza do you want (1-5) ?\n");
  scanf("%d", &kind);
  while(getchar() != '\n');
  
  printf("What size of pizza do you want (S, M, L) ?\n");
  scanf("%c", &size);
  while(getchar() != '\n');

  cost = 4.25 + (kind * 0.75);
  if (size == 'M')
    cost *= 1.5;
  else if (size == 'L')
    cost *= 2;

  printf("\nThe cost of the pizza is: $%0.2f\n", cost);
  printf("The price with tax is: $%0.2f\n", cost * 1.13);
  
  return 0;
}
