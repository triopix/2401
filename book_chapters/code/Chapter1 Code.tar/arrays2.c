#include <stdio.h>

int main() {
  int       ages[8]    = {34, 12, 45}; 
  char      vowels[8]  = {'a', 'e', 'i', 'o', 'u'};
  
  //ages[8] = 78;

  printf("\nHere is the ages array:\n");
  for (int i=0; i<15; i++)
    printf("%2d: %d\n",i, ages[i]);
  
  // Notice how data beyond boundary is invalid
  
  printf("\nHere is the vowels array:\n");
  for (int i=0; i<8; i++)
    printf("%2d: %c\n",i, vowels[i]);

  ages[8] = 78;   // This goes beyond bounds!!
                  // This will overwrite/corrupt
                  // any variables declared after it

  printf("\nHere is the vowels array:\n");
  for (int i=0; i<8; i++)
    printf("%2d: %c\n",i, vowels[i]);

  // Notice how data in vowels array is corrupt
  
  return(0);
}
