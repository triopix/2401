#include <stdio.h>

int main() {
  int       ages[8]    = {34, 12, 45}; 
  char      vowels[8]  = {'a', 'e', 'i', 'o', 'u'};

  printf("\nHere is the ages array:\n");
  for (int i=0; i<8; i++)
    printf("%2d: %d\n",i, ages[i]);
  
  printf("\nHere is the vowels array:\n");
  for (int i=0; i<8; i++)
    printf("%2d: %c\n",i, vowels[i]);

  return(0);
}
