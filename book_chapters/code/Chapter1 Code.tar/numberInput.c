
#include <stdio.h>

int main() {
  int  n1, n2, n3;
  
  printf("Enter three numbers:\n");
  
  scanf("%d", &n1);
  scanf("%d", &n2);
  scanf("%d", &n3);
  
  printf("The average is %g\n", (n1+n2+n3)/3.0);
 
  return 0;
}
