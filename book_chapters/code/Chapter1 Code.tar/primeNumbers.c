#include <stdio.h>

int main() {
    int	   isPrime;

    printf("The prime numbers from 1 to 100 are:\n");
    for (int i=1; i<=100000; i++) {
    	isPrime = 1;	// Assume that i is prime
	for (int j=2; j<i; j++) {
       	    if (i%j == 0) {
        	isPrime = 0; // if factor found, not prime
		break;
            }
      	}
      	if (isPrime)
	    printf("%d\n", i);
    }
 }
