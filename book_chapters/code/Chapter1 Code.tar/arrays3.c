/***********************************************************/
/* This program prompts the user for an array of integers  */
/* and then finds the maximum and prints it to the screen. */
/***********************************************************/

#include <stdio.h>

#define MAX_SIZE  10  // maximum numbers allowed to be entered by the user


int main() {
  int array[MAX_SIZE];

  // Get the numbers from the user
  int  totalNums = 0;
  int  num; 
  do {
    printf("Enter a number (use -1 to quit):  ");
    scanf("%d", &num);

    if (num != -1)
      array[totalNums++] = num;
      
  } while ((totalNums < MAX_SIZE) && (num != -1));
	

  // Compute the maximum of the array
  int max = 0;
  for (int i=0; i<totalNums; i++) {
    if (array[i] > max)
      max = array[i];
  }

  // Print the array
  printf("\nHere is the array:\n");
  for (int i=0; i<totalNums; i++)
    printf("%2d: %d\n",i, array[i]);

  // Print the maximum
  printf("\nMax is %d\n", max);

  return(0);
}
