#define DAYS_OF_WEEK   7
#define PI             3.14159
#define MAX            15
