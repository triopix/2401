#define MAX_STR 32

typedef struct {
  char first[MAX_STR];
  char last[MAX_STR];
} NameType;


void enterName(NameType *name);
void capFix(char *str);
