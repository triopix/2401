#include <stdio.h>
#include <string.h>

#include "linkExampleTypes.h"

int main() {
  NameType newName;

  while (1) {
    enterName(&newName);

    if ( strcmp(newName.first,"-1") == 0 && strcmp(newName.last,"-1") == 0 )
      break;

    capFix(newName.first);
    capFix(newName.last);

    printf("my name is %s %s\n",
           newName.first, newName.last);
  }
}

