#include <stdio.h>
#include "myDefinitions.h"

int main() {
  int  x = MAX;
  int *y = &x;
  
  printf("x + *y = %d\n", x + *y);
  printf("Days = %d, PI = %f\n", DAYS_OF_WEEK, PI);
}
