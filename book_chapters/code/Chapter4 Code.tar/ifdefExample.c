#include <stdio.h>
#include "myDefinitions.h"

//#define DEBUG 1

int main() {
  int  x = MAX;
  int *y = &x;
  
  #ifdef DEBUG
     printf("*y = %d\n", *y);
  #endif
  printf("x + *y = %d\n", x + *y);
  printf("Days = %d, PI = %f\n", DAYS_OF_WEEK, PI);
}
