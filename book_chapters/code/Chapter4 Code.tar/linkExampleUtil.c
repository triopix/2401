#include <stdio.h>
#include <string.h>

#include "linkExampleTypes.h"
 
void enterName(NameType *name) {
  printf("\n");
  printf("Enter a name: ");
  scanf("%s %s", name->first, name->last);
}

void capFix(char *str) {
  if (str[0] >= 'a' && str[0] <= 'z')
    str[0] = str[0] - 'a' + 'A';

  for (int i=1; i<strlen(str); i++)
    if (str[i] >= 'A' && str[i] <= 'Z')
      str[i] = str[i] - 'A' + 'a';
}

