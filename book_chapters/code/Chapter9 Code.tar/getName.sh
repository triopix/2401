#!/bin/sh
#This script asks for the user’s name
echo What is your name?
read NAME
echo $NAME is a cool name
