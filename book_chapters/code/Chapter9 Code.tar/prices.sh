#!/bin/sh
#Calculate price for buying X bags of milk and Y cartons of eggs
MILK=4   #Notice no spaces before or after the = sign
EGGS=2
echo How many bags of milk do you want? 
read NUM_MILK
echo How many cartons of eggs do you want? 
read NUM_EGGS

PRICE=`expr $NUM_MILK \* $MILK \+ $NUM_EGGS \* $EGGS`
echo The total price for $NUM_MILK bag\(s\) of milk and $NUM_EGGS carton\(s\) of eggs is \$$PRICE


