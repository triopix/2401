#!/bin/sh
#Calculate price for buying X bags of milk and Y cartons of eggs
# X and Y are supplied as command line arguments
echo The command is $0
echo There are $# command line arguments
echo The process ID is $$
MILK=4
EGGS=2
PRICE=`expr $1 \* $MILK \+ $2 \* $EGGS`
echo The total price for $1 bag\(s\) of milk and $2 carton\(s\) of eggs is \$$PRICE


