#!/bin/sh
#This script maintains the 2nd and 5th word from each setence
STR="The cat climbed the tree\nThe dog chased the stick\nThe turtle took a nap"
OUT=`echo $STR | cut -d " " -f 2,5`
echo $OUT
