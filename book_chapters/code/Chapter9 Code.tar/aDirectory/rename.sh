#!/bin/sh
#This script renames all files to uppercase

FILES=`ls`
for NAME in $FILES
do
  NEW_NAME=`echo $NAME | tr "[:lower:]" "[:upper:]"`
  if [ $NEW_NAME != $NAME ]; then
    mv $NAME $NEW_NAME
  fi
done





