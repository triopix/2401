#!/bin/sh
#Example showing how to use a while loop
RESPONSE=yes
while [ $RESPONSE = yes ]
do
  echo Do you want to loop again?
  read RESPONSE
done
echo Goodbye!


