#!/bin/sh
#This script uses ls -l and the examines the
#output to calculate the total files sizes
SIZES=`ls -l | cut -b 30-34`
TOTAL=0
for SIZE in $SIZES
do
  TOTAL=`expr $TOTAL + $SIZE`
done
echo Total of all file sizes = $TOTAL bytes
