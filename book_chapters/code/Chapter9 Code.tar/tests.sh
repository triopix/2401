#!/bin/sh
#This script tests out conditionals based on three integers entered on command line
if [ -z $3 ]; then
    echo ERROR I need three numbers
else
    if [ $1 -lt $2 ]; then
	if [ $1 -lt $3 ]; then
	    echo $1 is the smallest number
	else
	    echo $3 is the smallest number
	fi
    else
	if [ $2 -lt $3 ]; then
	    echo $2 is the smallest number
	else
	    echo $3 is the smallest number
	fi
    fi
fi

