#!/bin/sh
#This example just shows that we can loop through strings
for i in 1 2 5 A Z temp output 
do
    echo file$i.txt         #or can use file${i}.txt
done


