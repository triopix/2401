#!/bin/sh
#This script tests out the IF statement based on a command line name
if [ $1 = Mark ]; then
    echo Hello Mark
else if [ $1 = Christie ]; then
	 echo Hello Christie
     else
	 echo I do not know you
     fi
fi

