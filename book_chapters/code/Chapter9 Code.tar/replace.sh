#!/bin/sh
#This script does a search and replace for a string

STR="This sentence is about to be modified."
OUT=`echo $STR | tr e o`
echo $OUT




