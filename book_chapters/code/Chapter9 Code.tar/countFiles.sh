#!/bin/sh
#This script counts the files and directories

FILES=`ls`
FILE_COUNT=0
DIR_COUNT=0

for file in $FILES
do
    if [ -f $file ]; then
	FILE_COUNT=`expr $FILE_COUNT + 1`
    fi
    if [ -d $file ]; then
	DIR_COUNT=`expr $DIR_COUNT + 1`
    fi
done
echo There are $FILE_COUNT files and $DIR_COUNT directories



