#!/bin/sh
#This script lists all files in two ways

echo Here is the result of executing the \"ls\" command\:
echo
FILES=`ls`
echo $FILES
echo
echo Here are the files one at a time\:
echo
for i in $FILES
do
  echo Filename $i
done

