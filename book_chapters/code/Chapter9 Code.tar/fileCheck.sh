#!/bin/sh
#This script checks if a file or directory exists (specified as command
#line argument).  It also checks the permissions

if [ $# = 0 ]; then
    echo Error\: Missing Filename
    echo USAGE\: sh fileCheck.sh \<fileName\>
    exit
fi

if [ -f "$1" ]; then
    echo FILE \"$1\" exists
    if [ -r "$1" ]; then echo FILE is readable
    fi
    if [ -w "$1" ]; then echo FILE is writeable
    fi
    if [ -x "$1" ]; then echo FILE is executable
    fi
else
    if [ -d "$1" ]; then
	echo DIRECTORY \"$1\" exists
	if [ -r "$1" ]; then echo DIRECTORY is readable
	fi
	if [ -w "$1" ]; then echo DIRECTORY is writeable
	fi
	if [ -x "$1" ]; then echo DIRECTORY is executable
	fi
    else
	echo File/Directory \"$1\" not found
    fi
fi


