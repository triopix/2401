#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <unistd.h>
#include <math.h>

#define WIN_SIZE   600

int main() {
  Display *display; 
  Window   win;
  GC       gc;
  
  int           radius = 0;
  double        angle = 0;
  int           grayLevel = 200;
  unsigned int  color;
  
  // Opens connection to X server
  display = XOpenDisplay(NULL);

  // Create a simple window, set the title and get the graphics context then
  // make is visible and get ready to draw
  win = XCreateSimpleWindow(display, RootWindow(display, 0), 0, 0,	             
                            WIN_SIZE, WIN_SIZE, 0, 0x000000, 0xFFFFFF);               
  XStoreName(display, win, "Spirals");
  gc = XCreateGC(display, win, 0, NULL);

  // Make it visible
  XMapWindow(display, win);
  XFlush(display);
  usleep(20000);  // sleep for 20 milliseconds.
    
  // Go into infinite loop
  while(1) {
    color = (255-grayLevel)*65536 + (255-grayLevel)*256 + (255-grayLevel);
    XSetForeground(display, gc, color); 
    XFillArc(display, win, gc, (int)(cos(angle*M_PI/180)*radius)+WIN_SIZE/2,
	                       (int)(sin(angle*M_PI/180)*radius)+WIN_SIZE/2,
	                       10, 10, 0, 360*64);
    angle += 137.51;
    if (angle > 360)
      angle = angle - 360.0;
    
    radius = (radius + 1)%300;
    if (radius == 0)
      grayLevel = (grayLevel + 5) % 255;
    XFlush(display);
    usleep(500);
  }

  // Clean up and close the window
  XFreeGC(display, gc);
  XUnmapWindow(display, win);
  XDestroyWindow(display, win);
  XCloseDisplay(display);
}