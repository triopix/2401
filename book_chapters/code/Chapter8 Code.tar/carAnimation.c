#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <unistd.h>

#define  WIN_SIZE   600

// global variables
Display *display;
Window   win;
GC       gc;

void drawCar(int x, int y) {
  XPoint   polygon[4];
  
  // Draw the body
  XSetForeground(display, gc, 0x969696);
  XFillRectangle(display, win, gc, x, y-30, 100, 20);
  polygon[0].x = x+20;
  polygon[0].y = y-30;
  polygon[1].x = x+30;
  polygon[1].y = y-45;
  polygon[2].x = x+55;
  polygon[2].y = y-45;
  polygon[3].x = x+70;
  polygon[3].y = y-30;
  XFillPolygon(display, win, gc, polygon, 4, Convex, CoordModeOrigin);
  
  XSetForeground(display, gc, 0x000000);
  XDrawRectangle(display, win, gc, x, y-30, 100, 20);
  polygon[0].x = x+20;
  polygon[0].y = y-30;
  polygon[1].x = x+30;
  polygon[1].y = y-45;
  polygon[2].x = x+55;
  polygon[2].y = y-45;
  polygon[3].x = x+70;
  polygon[3].y = y-30;
  XDrawLines(display, win, gc, polygon, 4, CoordModeOrigin);

  // Draw the wheels
  XSetForeground(display, gc, 0x000000); // black
  XFillArc(display, win, gc, x+10, y-20, 20, 20, 0, 360*64);
  XFillArc(display, win, gc, x+70, y-20, 20, 20, 0, 360*64);
  
  XSetForeground(display, gc, 0xFFFFFF); // white
  XFillArc(display, win, gc, x+15, y-15, 10, 10, 0, 360*64);
  XFillArc(display, win, gc, x+75, y-15, 10, 10, 0, 360*64);
}



int main() {
  int    x = 0, y = 300;
  float  speed = 0;
  
  // Opens connection to X server
  display = XOpenDisplay(NULL);

  // Create a simple window, set the title and get the graphics context then
  // make is visible and get ready to draw
  win = XCreateSimpleWindow(display,  RootWindow(display, 0), 0, 0,
			    WIN_SIZE, WIN_SIZE/2, 0, 0x000000, 0xFFFFFF);
  XStoreName(display, win, "Car Animation");
  gc = XCreateGC(display, win, 0, NULL);
  XMapWindow(display, win);
  XFlush(display);
  usleep(20000);  // sleep for 20 milliseconds.
  
  // Go into infinite loop
  while(1) {
    XSetForeground(display, gc, 0xFFFFFF);
    XFillRectangle(display, win, gc, 0, 0, WIN_SIZE, WIN_SIZE/2);

    drawCar(x, y);

    x = (int)(x + speed);
    if (x+100 > WIN_SIZE)
      break;
    if (x+50 < WIN_SIZE/2)
      speed += 0.10;
    else 
      speed -= 0.10;
    XFlush(display);
    usleep(100000);
  }
  getchar();
  
  // Clean up and close the window
  XFreeGC(display, gc);
  XUnmapWindow(display, win);
  XDestroyWindow(display, win);
  XCloseDisplay(display);
}

